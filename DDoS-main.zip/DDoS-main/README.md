# Chức Năng 

* DDoS

* SOCKET
* PEM BẰNG URL V1
* PEM BẰNG URL V2
* CRINGE

# Cách Vào Tool

* Vào CH Play Hoặc Appstore Tải Google Cloud Để Chạy Tool Nhé!

* ```git clone https://github.com/viduchung/DDoS.git```
* ```cd DDoS; sh vdh.sh```

# Contact Me 
* Telegram: @hungtricker
* Zalo: 0359822840
* Facebook: @Users.ViDucHung.ProFile

# Donate 
* Momo: 0961136292
* Tsr: 0359822840
* MBBank: Đang Cập Nhật...

[![Hits](https://hits.seeyoufarm.com/api/count/incr/badge.svg?url=https://github.com/viduchung/DDoShit-counter&count_bg=%230BD4FF&title_bg=%23525050&icon=github.svg&icon_color=%23000000&title=Views&edge_flat=true)](https://hits.seeyoufarm.com)




